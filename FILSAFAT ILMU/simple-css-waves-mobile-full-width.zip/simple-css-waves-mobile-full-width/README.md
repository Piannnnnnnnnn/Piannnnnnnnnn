# Simple CSS Waves | Mobile & Full width

A Pen created on CodePen.io. Original URL: [https://codepen.io/goodkatz/pen/LYPGxQz](https://codepen.io/goodkatz/pen/LYPGxQz).

Lightweight animation between header & content. Easy to customize and apply into any website! Works with all devices and screen sizes.
# Carousel Slider With Owl.js

A Pen created on CodePen.io. Original URL: [https://codepen.io/tutsplus/pen/oPeLJR](https://codepen.io/tutsplus/pen/oPeLJR).

From [How to Build a Full-Screen Responsive Carousel Slider With Owl.js](http://webdesign.tutsplus.com/tutorials/how-to-build-a-full-screen-responsive-carousel-slider-with-owljs--cms-31771) by George M.